#include "State.h"
#include "ElectionRound.h"



namespace proj
{
	State::State():name(new char()), numOfRepresentative(0),numId(0), countCitizensInState(0),countVotesInState(0),stateStatus(true)
	{
		name = nullptr;
		
	}
	
	State::State(const State& sta)
	{
		numId = sta.numId;
		numOfRepresentative = sta.numOfRepresentative;
		name = utils::my_strdup(sta.name);
		countCitizensInState = sta.countCitizensInState;
		stateStatus = sta.stateStatus;
		countVotesInState = sta.countVotesInState;
	}

	State::State(istream& in)
	{
		load(in);
	}

	ostream& operator << (ostream& os, const State& state)
	{
		os << "state number: " << state.getNumId();
		os << "  ||  state name: " << state.getName();
		os << "  ||  state number of rep: " << state.getNumOfRepresentative();
		if (state.getStateStatus())
			os << "  ||  state brand: union "<<endl;
		else
			os << "  ||  state brand: sperated "<< endl;

		return os;
	}

	State::~State()
	{
		delete[] name;
	}

	const State& State::operator=(const State& input)
	{
		numId = input.numId;
		numOfRepresentative = input.numOfRepresentative;
		name = input.name;
		countCitizensInState = input.countCitizensInState;
		countVotesInState = input.countVotesInState;
		return *this;
	}
	State::State(const char* _name, int _numRep ,bool Status) : State()
	{
		ElectionRound::countState++;
		numId = ElectionRound::countState;
		numOfRepresentative = _numRep;
		name = utils::my_strdup(_name);
		stateStatus = Status;
	}
	bool State::getStateStatus()const
	{
		return stateStatus;
	}
	const char* State::getName()const
	{
		return name;
	}
	int State::getNumId()const
	{
		return numId;
	}
	int State::getNumOfRepresentative()const
	{
		return numOfRepresentative;
	}
	int State::getHowManyCitizens()const
	{
		return countCitizensInState;
	}

	int State::getCountVotesInState()const
	{
		return countVotesInState;
	}

	void State::addCitizen()
	{
	 countCitizensInState++; 
	}

	void State::addVote()
	{
		countVotesInState++;
	}
	bool State::save(ostream& out) const
	{
		if (!out)
		{
			return false;
		}

		out.write(rcastcc(&numId), sizeof(int));
		out.write(rcastcc(&numOfRepresentative), sizeof(int));
		out.write(rcastcc(&countCitizensInState), sizeof(countCitizensInState));
		out.write(rcastcc(&countVotesInState), sizeof(countVotesInState));
		out.write(rcastcc(&stateStatus), sizeof(stateStatus));
		int len;
		len = utils::myStrlen(name);
		out.write(rcastcc(&len), sizeof(int));
		out.write(rcastcc(name), len);
		
		return (out.good());
	}

	bool State::load(istream& in)
	{
		if (!in)
		{
			return false;
		}
		in.read(rcastc(&numId), sizeof(int));
		in.read(rcastc(&numOfRepresentative), sizeof(int));
		in.read(rcastc(&countCitizensInState), sizeof(countCitizensInState));
		in.read(rcastc(&countVotesInState), sizeof(countVotesInState));
		in.read(rcastc(&stateStatus), sizeof(stateStatus));
		
		int len;
		in.read(rcastc(&len), sizeof(len));
		if (!in.good())
		{
			return false;
		}
		len++;
		
		name = new char[len];

		in.read(name, len-1);

		name[len - 1] = '\0';
	
		return (in.good());
	}
}